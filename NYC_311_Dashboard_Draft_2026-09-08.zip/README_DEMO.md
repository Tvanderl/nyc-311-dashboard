# NYC 311 Service Performance Dashboard

## Open the live demo

Open `nyc311-interactive-demo.html` in a modern browser while the computer has internet access. The dashboard retrieves current aggregates and source records from the official NYC Open Data dataset `erm2-nwe9`.

The HTML file contains the dashboard logic and calculations. It does **not** contain the entire NYC 311 dataset, because that source is large and continually updated. No data is uploaded from this dashboard.

## Internet requirement

The following features need an internet connection:

- loading the current filtered request totals;
- year, agency, borough and problem-type values from the source;
- annual trend, rankings, budget comparison and forecast inputs;
- drill-through records and per-record source links.

## Included documentation

- `NYC_311_Service_Performance_Dashboard_Assignment.docx` — paper with data flow, wireframe and model.
- `NYC_311_Dashboard_Pitch.pptx` — presentation deck.
- `NYC_311_PowerBI_Query_and_DAX.txt` — Power BI source-query and DAX specification.
- `RUBRIC_READINESS_NYC_311.md` — requirement checklist.

## Before Canvas submission

Add your group details, create the final `.pbix` in Power BI Desktop and include the Excel/Access data mart used by that PBIX. The assignment requests those files in addition to the paper, presentation and functioning dashboard.
