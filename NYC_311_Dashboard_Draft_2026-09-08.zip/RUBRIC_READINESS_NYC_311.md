# NYC 311 dashboard — rubric readiness

This checklist translates the assignment brief into concrete evidence for the submission. It is an audit aid, not a guarantee of a grade.

| Assignment requirement | Evidence in the current package | Status before submission |
|---|---|---|
| Fully functioning performance dashboard | `nyc311-interactive-demo.html` uses the official live NYC 311 API; it has global filters, cross-filtering, Month focus, time navigation and source-record drill-through. | Ready after a final laptop/internet test |
| Multiple numerical KPIs | Request volume, peak demand month, budget variance, forecast, MSE and risk/opportunity variance. | Ready |
| Multiple categorical dimensions | Year, Month focus, Agency, Borough and Problem type. The lists load from the selected year in the official source. | Ready |
| Basic OLAP functionality | Slice/dice with five dimensions, ranked cross-filtering, annual time navigation, zoom/pan, focused-month views and drill-through. | Ready |
| Actual versus budget | Budget is the matching prior-year month plus 5%; current actual, variance and variance percentage appear on Overview and Budget analysis. | Ready |
| Moving-average forecast and MSE | Three-month moving average, per-month forecast error and rolling mean squared error. | Ready |
| Risks and opportunities | Tornado chart and monthly heat map use red for demand above budget and green for capacity released below budget. | Ready |
| Multiple relevant visual components | KPI cards, annual line, monthly combo trend, ranked bars, budget table, forecast table, heat map, tornado, traffic-light signals and drill-through table. | Ready |
| Effective, non-cluttered design | Summary first, analysis on separate pages, consistent colour meanings, contextual labels and accessible focus states. | Ready |
| Data source/data mart | Official NYC Open Data source and Power BI query/DAX specification are included. | Create and include the actual Excel or Access data mart used in the final PBIX |
| MS Power BI + Access/Excel technical solution | `NYC_311_PowerBI_Query_and_DAX.txt` specifies the source query and measures. | Create, save and include the `.pbix` in Power BI Desktop; this is still required |
| Paper: KPIs, transformations, DFD, OLAP model, warehouse, wireframe, analyses, maintenance | `NYC_311_Service_Performance_Dashboard_Assignment.docx` contains the written package. | Fill in title page group number, names and student numbers; review captions and references |
| PowerPoint and 10-minute pitch | `NYC_311_Dashboard_Pitch.pptx` gives an 8-slide, 8-minute narrative plus time for the live demo and questions. | Fill in team details and rehearse the live demo |

## Recommended live-demo sequence

1. Start on **Overview** and explain the management question.
2. Use **Year**, **Month focus**, **Agency**, **Borough** and **Problem type** to demonstrate OLAP filtering.
3. Open **Budget analysis** for actual versus budget.
4. Open **Forecast and risk** for the moving average, MSE, tornado and heat map.
5. Click a month and show **Request detail** with the matching live records.

## Submission package

Include the dashboard, the final `.pbix`, its Excel/Access data mart, the paper and the presentation in one compressed file. The assignment brief requires all five. Replace every bracketed group placeholder before uploading.
